PRM =
{
	ModID : "mod_rpgr_parameters",
	Classes : {},
	Patcher : {},
	Utilities : {},
	Enums : {}
};