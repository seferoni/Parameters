PRM.Enums.MouseButtons =
{
	LEFT : 1,
	MIDDLE : 2,
	RIGHT : 3
};

PRM.Enums.MSUState =
{
	NotFound : "___MSUnotFound",
	Found : "___MSUfound"
};